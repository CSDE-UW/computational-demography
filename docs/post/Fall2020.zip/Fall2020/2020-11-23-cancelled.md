---
title: Cancelled
author: Zack Almquist
date: '2020-11-23'
slug: No meeting
categories:
  - 
tags:
  - Thanksgiving
---

No meeting Thanksgiving Holiday week.
