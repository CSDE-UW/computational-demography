---
title: Research Plan Development
author: Zack Almquist
date: '2020-10-26'
slug: Research Plans
categories:
  - Professional Development
tags:
  - 
---

This week's meeting will be focused on Research Plan Development and will be led by [Christine Leibbrand](https://csde.washington.edu/staff/christine-leibbrand/) the Training Director of CSDE and past CSDE Fellow. The research plan will be developed in alignment with NIH K-award type framework. We will reserve one-two meetings a quarter to work on and workshop research plans each quarter.

